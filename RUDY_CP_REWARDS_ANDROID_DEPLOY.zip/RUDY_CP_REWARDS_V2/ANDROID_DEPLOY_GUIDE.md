# Deploy RUDY CP REWARDS V2 from Android (Render)

This project is a Node.js + SQLite app. The persistent disk in `render.yaml` is important: without persistent storage, player accounts and claims can be lost when the service restarts. Render's persistent disk is a paid feature; check the current price before confirming deployment.

## What you need
- A GitHub account
- A Render account
- A strong unique admin password (12+ characters)
- A random session secret (32+ characters)

## Android steps
1. In your phone browser, sign in to GitHub and create a new private repository named `rudy-cp-rewards`.
2. Upload the contents of this project folder to the repository. Upload the files inside `RUDY_CP_REWARDS_V2`, not the outer ZIP or parent folder. Keep the `public` folder and all root files.
3. Open Render and choose **New + → Blueprint**. Connect GitHub and select `rudy-cp-rewards`.
4. Review the service and persistent disk in `render.yaml`. The disk is needed for SQLite data. Confirm the plan and any displayed charges before deploying.
5. In the Render service's Environment settings, add:
   - `NODE_ENV` = `production`
   - `ADMIN_USERNAME` = a username you choose
   - `ADMIN_PASSWORD` = a unique password of at least 12 characters
   - `SESSION_SECRET` = a random secret of at least 32 characters
   - `SITE_NAME` = `RUDY CP REWARDS`
   Render provides `PORT` automatically; do not set it manually unless required.
6. Deploy and wait for the service to become **Live**. Open the provided `onrender.com` URL.
7. In the Render service dashboard, open **Shell** and run `npm run bootstrap-admin` once. This creates/updates the administrator account using the environment variables above.
8. Open `https://YOUR-SERVICE.onrender.com/admin.html` and sign in with your admin username and password.

## Safety
- Never send me or anyone your passwords, session secret, OTP, payment PIN, or recovery codes.
- Do not collect Activision passwords or OTPs from players.
- This site tracks community campaign claims; it does not generate or transfer COD Points. Fulfil any real prize only through an authorized Activision/Call of Duty method.
- Before public launch, add your own privacy policy, terms, eligibility rules, and contact details.
