require("dotenv").config();
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const path = require("path");
const username = process.env.ADMIN_USERNAME || "admin";
const password = process.env.ADMIN_PASSWORD || "";
if (password.length < 12) throw new Error("Set ADMIN_PASSWORD to at least 12 characters first.");
const db = new Database(path.join(__dirname, "data", "rudy.sqlite"));
const hash = bcrypt.hashSync(password, 12);
const existing = db.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE").get(username);
if (existing) {
  db.prepare("UPDATE users SET password_hash=?, role='admin', disabled=0 WHERE id=?").run(hash, existing.id);
} else {
  db.prepare("INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,'admin')").run(username, `${username}@admin.invalid`, hash);
}
console.log(`Admin account ready: ${username}`);
db.close();
